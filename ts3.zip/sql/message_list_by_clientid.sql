select * from messages where server_id = :server_id: and message_to_client_id= :message_to_client_id:;
